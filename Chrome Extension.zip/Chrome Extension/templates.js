var addNoteForm = '<form><input type="hidden" name="hiddenField" /></form><pre><p class="whodis-note">Add Note!</p></pre>';

var temporaryInjection = "<a href=\"#\" id=\"username\" data-type=\"text\" data-pk=\"1\" data-url=\"/post\" data-title=\"Enter username\">superuser</a>";
